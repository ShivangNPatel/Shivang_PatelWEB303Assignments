/*
	WEB 303 Assignment 1 - jQuery
	Name: Shivang Nitinchandra Patel

*/
	
$(document).ready(function() {

	$("#yearly-salary, #percent").on("keyup", function() {		 
	
		let salary = $("#yearly-salary").val();

		let percent = $("#percent").val();

		let finalAmount = salary * percent / 100;
		
		$("#amount").text("$" + finalAmount).toFixed(2);
	
  	});

});